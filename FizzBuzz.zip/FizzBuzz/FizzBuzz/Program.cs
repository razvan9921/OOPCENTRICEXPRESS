﻿using System;

namespace FizzBuzz
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            var fizzBuzz = new FizzBuzz();

            for (int i = 0; i < 100; i++)
            {
                Console.WriteLine(fizzBuzz.GetFizzBuzz(i));
            }

            //Console.ReadKey();
        }
    }
}
