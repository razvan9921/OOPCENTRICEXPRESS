using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FizzBuzzTest
{
    [TestClass]
    public class FizzBuzzTests
    {
        private FizzBuzz.FizzBuzz fizzBuzz;

        [TestInitialize]
        public void SetUp()
        {
            fizzBuzz = new FizzBuzz.FizzBuzz();
        }

        [TestMethod]
        public void When_NumberIsNotMultipleOfThreeOrFive_Then_ReturnNumber()
        {
            //Arrange
            var number = 1;

            //Act
            var result = fizzBuzz.GetFizzBuzz(number);

            //Assert
            Assert.AreEqual(expected: "1", actual: result);
        }

        [TestMethod]
        public void When_NumberIsMultipleOfThree_Then_Return_Fizz()
        {
            //Arrange
            var number = 3;

            //Act
            var newReturn = fizzBuzz.GetFizzBuzz(number);

            //Assert
            Assert.AreEqual(expected: "fizz", actual: newReturn);
        }
        [TestMethod]
        public void When_NumberIsMultipleOfFive_Then_Return_Buzz()
        {
            //Arrange
            var number = 5;

            //Act
            var newReturn = fizzBuzz.GetFizzBuzz(number);

            //Assert
            Assert.AreEqual(expected: "buzz", actual: newReturn);
        }

        [TestMethod]
        public void When_NumberIsMultipleOfThreeAndFive_Then_Return_FizzBuzz()
        {
            //Arrange
            var number = 15;

            //Act
            var newReturn = fizzBuzz.GetFizzBuzz(number);

            //Assert
            Assert.AreEqual(expected: "fizzbuzz", actual: newReturn);
        }
    }
}
